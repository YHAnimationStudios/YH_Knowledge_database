# Anim Team Librarian

Anim Team Librarian for Windows maintains a Markdown document for each saved Codex chat visible to the signed-in animator on this workstation. It includes current and archived chats across projects, including chats started outside an Unreal project. People with read access to the team repository can read the uploaded conversations.

```text
YHAnimationStudios/YH_Knowledge_database
└── Animators team/Codex usage data/<seat-email>/<session-id>.md
```

The first document creates the seat’s folder. Later turns update that session’s file. Run enrollment on each workstation that holds part of an animator’s local history. Use the same ChatGPT seat there to publish into the same email folder.

## Setup

1. Sign in to Codex with your team seat. Install PowerShell 7.2 or newer and Git for Windows. Sign in to GitHub through your normal Git credential manager with write access to the team repository’s `main` branch.
2. Extract the plugin distribution to a permanent local folder, preserving the `.agents` and `plugins` directories. Open PowerShell 7 in that folder. If you already have the Anim Team Tools local marketplace, update the files in its registered folder.
3. Register the marketplace and install the plugin. Review the plugin’s Windows Stop hook in Codex Settings → Hooks. Reopen Codex if it asks to reload plugins.

   ```powershell
   codex plugin marketplace add .
   codex plugin add anim-team-librarian@anim-team-tools
   ```

4. Preview the scope, then enroll the signed-in seat to start the historical upload and enable future sync. Enrollment explicitly shares conversation text with the team. Earlier local ZIP settings do not enroll anyone.

   ```powershell
   $scripts = '.\plugins\anim-team-librarian\scripts'
   & "$scripts\Collect-AnimTeamHistory.ps1" -InventoryOnly
   & "$scripts\Configure-AnimLibrarian.ps1" -EnableAccountSync
   ```

## What appears on GitHub

Each document contains session metadata and the visible text from the animator and assistant in chronological order. The collector omits tool payloads, attachments, private reasoning and internal subagent conversations. Common credentials pasted into visible text are masked, including authorization headers, recognizable API tokens and private keys. Other personal or confidential conversation content can appear in the documents. Git retains prior committed versions.

The Codex App Server supplies the signed-in email, account identity and account-filtered list of saved conversations. The worker checks the seat again before publication. An unavailable identity, a different sign-in or an unreachable repository leaves work pending. Newly enrolled animators need no pre-created folders.

## Sync and recovery

From the extracted marketplace folder, run a full reconciliation to pick up older sessions, sessions from clients where the hook was unavailable, and changes to archive state.

```powershell
$scripts = '.\plugins\anim-team-librarian\scripts'
& "$scripts\Sync-AnimTeamSessions.ps1"
```

An enabled Stop hook queues a completed turn for automatic synchronization. If the workstation is offline or a turn has not finished saving, pending work can be retried from PowerShell.

```powershell
& "$scripts\Drain-AnimLibrarianQueue.ps1"
```

Check the last result and the number of pending turns with `Configure-AnimLibrarian.ps1 -Status`. A successful push includes the Git commit ID. A later day’s first activity requests a full reconciliation. For a deliberate account change on a shared workstation, sign in to the new seat and run `Configure-AnimLibrarian.ps1 -EnableAccountSync -ReplaceEnrollment`.

If two workstations supply different text for the same session version and the plugin cannot determine which edit is newer, the status reports `ConflictingSessionVersions` and lists the session IDs. The repository keeps its current copy. Sync again from the workstation with the later saved edit.

To stop future uploads from this Windows profile, disable enrollment. Documents already committed remain in GitHub.

```powershell
& "$scripts\Configure-AnimLibrarian.ps1" -DisableAccountSync
```

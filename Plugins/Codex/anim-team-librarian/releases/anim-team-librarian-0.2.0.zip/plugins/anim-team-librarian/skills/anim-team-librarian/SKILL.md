---
name: anim-team-librarian
description: Use when an animator asks to count their saved Codex sessions, enable team GitHub sync, backfill all of their sessions, inspect pending uploads, or disable sync.
---

# Anim Team Librarian

Use the bundled Windows scripts with PowerShell 7.2 or later. The destination is `YHAnimationStudios/YH_Knowledge_database`, branch `main`, under `Animators team/Codex usage data/<signed-in-seat-email>/<session-id>.md`. The source includes the seat’s saved active and archived conversations across all projects on this workstation.

- For a count, run `scripts/Collect-AnimTeamHistory.ps1 -InventoryOnly`. It reports counts without exporting message bodies.
- When the animator expressly asks to share their usage with this team repository, use `scripts/Configure-AnimLibrarian.ps1 -EnableAccountSync` to enroll the signed-in seat and start the backfill. For a previously enrolled seat use `scripts/Sync-AnimTeamSessions.ps1` to reconcile all sessions.
- Use `scripts/Drain-AnimLibrarianQueue.ps1` to retry pending work. Report the counts, pending or failed work and the verified Git commit if one was returned. Keep transcript text out of routine status reports.
- For a request to stop future uploads, run `scripts/Configure-AnimLibrarian.ps1 -DisableAccountSync`. Disabling sync preserves repository history.
- If the active account or repository check fails, report that specific blocker. The current seat and repository path are determined by the plugin.

See [setup and recovery](../../README.md).

#requires -Version 7.2
[CmdletBinding(DefaultParameterSetName='Inspect')]
param(
    [Parameter(Mandatory,ParameterSetName='Enable')] [switch] $EnableAccountSync,
    [Parameter(ParameterSetName='Enable')] [switch] $ReplaceEnrollment,
    [Parameter(Mandatory,ParameterSetName='Disable')] [switch] $DisableAccountSync,
    [Parameter(ParameterSetName='Inspect')] [switch] $Status
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'LibrarianState.ps1')
$directory = Get-LibrarianStateDirectory
if ($PSCmdlet.ParameterSetName -eq 'Inspect') {
    Get-LibrarianStatus (Get-LibrarianConfig $directory) $directory | ConvertTo-Json -Compress
    return
}

New-LibrarianPrivateDirectory $directory
$path = Join-Path $directory 'account-sync.json'
$lock = Open-LibrarianLock (Join-Path $directory 'enrollment.lock')
try {
    $previous = Get-LibrarianConfig $directory
    if ($DisableAccountSync) {
        if ($previous) {
            $previous.mode = 'Disabled'
            Write-LibrarianJson $path $previous -Replace
        }
        Get-LibrarianStatus $previous $directory | ConvertTo-Json -Compress
        return
    }

    $runtime = [Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
    if ([IO.Path]::GetFileName($runtime) -ne 'pwsh.exe') { throw 'Run enrollment from PowerShell 7.' }
    try { $identity = Get-LibrarianIdentity } catch { throw 'Could not verify the signed-in ChatGPT email and user ID.' }
    if ($previous -and -not (Test-LibrarianBinding $previous $identity) -and -not $ReplaceEnrollment) {
        throw 'This Windows seat is enrolled for another account. Sign back in or explicitly use -EnableAccountSync -ReplaceEnrollment.'
    }
    if ($previous.mode -eq 'AccountSync' -and (Test-LibrarianBinding $previous $identity)) {
        $enrollment = $previous.enrollmentId
        $seat = Get-LibrarianSeatDirectory $directory $enrollment
    } else {
        $enrollment = [guid]::NewGuid().ToString('N')
        $seat = Join-Path $directory ('seat-' + $enrollment)
        New-LibrarianPrivateDirectory $seat
    }
    $configuration = [ordered]@{
        schemaVersion=2; mode='AccountSync'; email=[string]$identity.email; userId=[string]$identity.userId
        enrollmentId=$enrollment; powerShellPath=$runtime
    }
    Add-LibrarianFullRequest $seat $enrollment
    Write-LibrarianJson $path $configuration -Replace
} finally { $lock.Dispose() }

& (Join-Path $PSScriptRoot 'Drain-AnimLibrarianQueue.ps1') -EnrollmentId $enrollment -RequestFull


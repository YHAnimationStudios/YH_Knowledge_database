#requires -Version 7.2
[CmdletBinding()]
param(
    [ValidatePattern('^[a-f0-9]{32}$')] [string] $EnrollmentId,
    [switch] $Background,
    [switch] $RequestFull
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'LibrarianState.ps1')

function Clear-LibrarianStage([string] $Seat, [string] $Path) {
    $absolute = [IO.Path]::GetFullPath($Path)
    if ([IO.Path]::GetDirectoryName($absolute) -ne [IO.Path]::GetFullPath($Seat) -or
        [IO.Path]::GetFileName($absolute) -cnotmatch '^run-[0-9a-f]{32}$') { throw 'Invalid staging location.' }
    Assert-LibrarianPrivatePath $absolute -Protected
    if ([IO.Directory]::Exists($absolute)) { [IO.Directory]::Delete($absolute,$true) }
}

function Get-QueuedTurns([string] $Seat, [string] $Enrollment) {
    # Unresolved events move to the back after each attempt so they cannot starve later sessions.
    foreach ($file in (Get-ChildItem -LiteralPath $Seat -Filter 'turn-*.json' -File |
            Sort-Object LastWriteTimeUtc,Name | Select-Object -First 200)) {
        Assert-LibrarianPrivatePath $file.FullName
        $event = Read-LibrarianJson $file.FullName
        $key = [string]$event.turnKey
        if ($event.enrollmentId -cne $Enrollment -or
            $key -cnotmatch '^([0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12})\|[a-zA-Z0-9_.-]{1,160}$' -or
            $file.Name -cne ('turn-' + (Get-LibrarianKey $key) + '.json')) { throw 'Invalid queued event.' }
        [pscustomobject]@{key=$key; sessionId=$Matches[1]; path=$file.FullName}
    }
}

function Assert-Counts($Object, [string[]] $Names) {
    foreach ($name in $Names) {
        $value = $Object.$name
        if (($value -isnot [int] -and $value -isnot [long]) -or $value -lt 0) {
            throw 'Invalid component result.'
        }
    }
}

function Set-RpcDiagnostic($Record, $Diagnostic) {
    if (-not $Diagnostic) { return }
    if ($Diagnostic.stage -cin @('inputs','app-server','identity','account-inventory','private-staging','session-export','session-read','session-write','final-identity')) {
        $Record.collectorStage = $Diagnostic.stage
    }
    $method = $Diagnostic.rpcMethod
    if ($method -cin @('initialize','account/read','thread/list','thread/turns/list','thread/items/list','thread/read')) {
        $Record.rpcMethod = $method
    }
    $code = $Diagnostic.rpcCode
    if ($code -is [int] -or $code -is [long]) { $Record.rpcCode = $code }
}

function Invoke-QueuePass($Config, [string] $Directory, [string] $Seat) {
    $record = [ordered]@{status='Idle'; scope='None'; reason=$null; email=$Config.email
        activeThreads=0; archivedThreads=0; documents=0; skipped=0; failures=0
        pushed=0; unchanged=0; older=0; conflicts=0; conflictSessions=@(); commit=$null}
    $stage = $null
    $events = @()
    $reason = 'QueueReadFailed'
    try {
        $active = Get-LibrarianConfig $Directory
        if ($active.mode -ne 'AccountSync' -or $active.enrollmentId -cne $Config.enrollmentId) {
            $record.status = 'Disabled'
            return $record
        }
        # An interrupted process can leave a private run directory behind. The per-seat
        # collection lock ensures no other collector can still be using it.
        foreach ($orphan in [IO.Directory]::GetDirectories($Seat,'run-*')) { Clear-LibrarianStage $Seat $orphan }
        $full = @(Get-ChildItem -LiteralPath $Seat -Filter 'full-*.json' -File)
        foreach ($file in $full) {
            Assert-LibrarianPrivatePath $file.FullName
            $request = Read-LibrarianJson $file.FullName
            if ($request.enrollmentId -cne $Config.enrollmentId) { throw 'Invalid full sync request.' }
        }
        $events = @(Get-QueuedTurns $Seat $Config.enrollmentId)
        if (-not ($events.Count -or $full.Count)) { return $record }
        $record.scope = if ($full.Count) { 'Full' } else { 'Incremental' }
        $reason = 'AccountVerificationFailed'
        if (-not (Test-LibrarianBinding $Config (Get-LibrarianIdentity))) { $reason='AccountChanged'; throw 'Hold' }
        $reason = 'DestinationVisibilityUnverified'
        if ((Get-LibrarianRepositoryHttpStatus) -ne 404) { throw 'Hold' }
        $reason = 'CollectionFailed'
        $stage = Join-Path $Seat ('run-' + [guid]::NewGuid().ToString('N'))
        New-LibrarianPrivateDirectory $stage
        $params = @{OutputDirectory=$stage; ExpectedEmail=$Config.email; PinnedUserId=$Config.userId}
        if ($events.Count) { $params.TrackedTurns = [string[]]$events.key }
        if (-not $full.Count) { $params.SessionId = [string[]]@($events.sessionId | Sort-Object -Unique) }
        $collection = & (Join-Path $PSScriptRoot 'Collect-AnimTeamHistory.ps1') @params 2>$null | ConvertFrom-Json
        if (-not (Test-LibrarianBinding $Config $collection)) { $reason='AccountChanged'; throw 'Hold' }
        $counters = @('activeThreads','archivedThreads','documents','skipped','failures')
        Assert-Counts $collection $counters
        foreach ($name in $counters) { $record[$name] = $collection.$name }
        if ($record.failures) { Set-RpcDiagnostic $record $collection.lastFailure }
        $observed = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
        foreach ($key in $collection.observedTurns) { $null = $observed.Add([string]$key) }
        $docs = [IO.Directory]::GetFiles($stage,'*.md')
        if ($docs.Length -ne $record.documents) { throw 'Unexpected staged document count.' }

        # Changes to enrollment serialize with the outbound transaction. A Stop can keep
        # enqueueing during a long backfill, including during Git operations.
        $gate = Open-LibrarianLock (Join-Path $Directory 'enrollment.lock')
        try {
            $active = Get-LibrarianConfig $Directory
            if ($active.mode -ne 'AccountSync' -or $active.enrollmentId -cne $Config.enrollmentId -or
                -not (Test-LibrarianBinding $Config $active)) { $reason='EnrollmentChanged'; throw 'Hold' }
            $reason = 'AccountVerificationFailed'
            if (-not (Test-LibrarianBinding $Config (Get-LibrarianIdentity))) { $reason='AccountChanged'; throw 'Hold' }
            if ($docs.Length -gt 0) {
                $reason = 'PublishFailed'
                $published = & (Join-Path $PSScriptRoot 'Publish-AnimTeamSessions.ps1') -DocumentDirectory $stage -Email $Config.email -StateDirectory $Seat 2>$null | ConvertFrom-Json
                Assert-Counts $published @('pushed','unchanged','older')
                if ($null -ne $published.conflicts) {
                    Assert-Counts $published @('conflicts')
                    $record.conflicts = $published.conflicts
                }
                $conflicting = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
                foreach ($id in $published.conflictSessions) {
                    if ($id -isnot [string] -or $id -cnotmatch '^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$' -or
                        -not $conflicting.Add($id) -or -not [IO.File]::Exists((Join-Path $stage ($id + '.md')))) {
                        throw 'Invalid conflict session.'
                    }
                }
                if ($conflicting.Count -ne $record.conflicts -or
                    ($published.pushed + $published.unchanged + $published.older + $record.conflicts) -ne $record.documents) {
                    throw 'Unaccounted staged documents.'
                }
                $record.conflictSessions = @($conflicting | Sort-Object)
                foreach ($name in @('pushed','unchanged','older','commit')) { $record[$name] = $published.$name }
            }
            $reason = 'CheckpointFailed'
            foreach ($event in $events) {
                if ($observed.Contains($event.key) -and $event.sessionId -notin @($collection.missing) -and
                    $event.sessionId -notin $record.conflictSessions) { [IO.File]::Delete($event.path) }
            }
            if ($full.Count -and $record.failures -eq 0 -and $record.conflicts -eq 0) {
                Write-LibrarianJson (Join-Path $Seat 'last-full.json') @{utcDate=[DateTime]::UtcNow.ToString('yyyy-MM-dd')} -Replace
                foreach ($file in $full) { [IO.File]::Delete($file.FullName) }
            }
        } finally { $gate.Dispose() }
        $unobserved = @($events | Where-Object { [IO.File]::Exists($_.path) })
        $record.status = 'Synced'
        if ($record.conflicts -or $record.failures -or $unobserved.Count) {
            $record.status = 'RetryPending'
            $record.reason = if ($record.conflicts) { 'ConflictingSessionVersions' }
                elseif ($record.failures) { 'CollectionIncomplete' } else { 'AwaitingPersistedTurn' }
        }
    } catch {
        $record.status = 'RetryPending'
        $record.reason = $reason
        for ($cause=$_.Exception; $cause; $cause=$cause.InnerException) { Set-RpcDiagnostic $record $cause.Data }
    } finally {
        foreach ($event in $events) {
            if ([IO.File]::Exists($event.path)) { [IO.File]::SetLastWriteTimeUtc($event.path,[DateTime]::UtcNow) }
        }
        if ($stage) { Clear-LibrarianStage $Seat $stage }
        $pending = Get-LibrarianPending $Seat
        $record.pendingTurns = $pending.pendingTurns
        $record.pendingFull = $pending.pendingFull
        $record.checkedAtUtc = [DateTimeOffset]::UtcNow.ToString('o')
        if ($record.status -eq 'Synced' -and ($record.pendingTurns -or $record.pendingFull)) { $record.status='Pending' }
        if ($record.scope -ne 'None' -or $record.status -eq 'RetryPending') {
            Write-LibrarianJson (Join-Path $Seat 'status.json') $record -Replace
        }
    }
    return $record
}

$directory = Get-LibrarianStateDirectory
$config = Get-LibrarianConfig $directory
if ($config.mode -ne 'AccountSync' -or ($EnrollmentId -and $config.enrollmentId -cne $EnrollmentId)) {
    if (-not $Background) { Get-LibrarianStatus $config $directory | ConvertTo-Json -Compress }
    return
}
$seat = Get-LibrarianSeatDirectory $directory $config.enrollmentId
$delay = 2
$failures = 0
$wakePath = Join-Path $seat 'wake.json'
$initialWindow = [DateTime]::UtcNow
do {
    if ($Background) {
        Assert-LibrarianPrivatePath $wakePath
        $wake = if ([IO.File]::Exists($wakePath)) { (Read-LibrarianJson $wakePath).generation }
    }
    $lock = Open-LibrarianLock (Join-Path $seat 'collection.lock')
    try {
        if ($RequestFull) { Add-LibrarianFullRequest $seat $config.enrollmentId }
        $result = Invoke-QueuePass $config $directory $seat
    } finally { $lock.Dispose() }
    if (-not $Background) {
        if ($result.status -in @('Pending','RetryPending')) { Start-LibrarianWorker $config $seat }
        $result | ConvertTo-Json -Compress
        return
    }

    # Use the same short dispatch lock as the hook. If a Stop arrives during exit it
    # either leaves work here or sees the runner unregistered and starts a new worker.
    $dispatch = Open-LibrarianLock (Join-Path $seat 'dispatch.lock')
    try {
        $active = Get-LibrarianConfig $directory
        $pending = Get-LibrarianPending $seat
        $latest = if ([IO.File]::Exists($wakePath)) { (Read-LibrarianJson $wakePath).generation }
        if ($result.status -eq 'RetryPending' -and $wake -ceq $latest) { $failures++ } else { $failures=0 }
        # Finish giving the existing incremental backlog one pass before yielding.
        $untouched = $false
        if ($pending.pendingTurns -gt 200 -and $result.scope -eq 'Incremental' -and
            $result.reason -in @('CollectionIncomplete','AwaitingPersistedTurn','ConflictingSessionVersions')) {
            $untouched = $null -ne (Get-ChildItem -LiteralPath $seat -File -Filter 'turn-*.json' |
                Where-Object LastWriteTimeUtc -lt $initialWindow | Select-Object -First 1)
        }
        if ($active.mode -ne 'AccountSync' -or $active.enrollmentId -cne $config.enrollmentId -or
            -not ($pending.pendingTurns -or $pending.pendingFull) -or ($failures -ge 3 -and -not $untouched)) {
            $runnerPath = Join-Path $seat 'runner.json'
            Assert-LibrarianPrivatePath $runnerPath
            if ([IO.File]::Exists($runnerPath) -and (Read-LibrarianJson $runnerPath).processId -eq $PID) {
                [IO.File]::Delete($runnerPath)
            }
            return
        }
    } finally { $dispatch.Dispose() }
    if ($result.status -eq 'RetryPending' -and -not $untouched) {
        Start-Sleep -Seconds $delay
        $delay = [Math]::Min($delay * 2,300)
    } else { $delay = 2 }
} while ($Background)

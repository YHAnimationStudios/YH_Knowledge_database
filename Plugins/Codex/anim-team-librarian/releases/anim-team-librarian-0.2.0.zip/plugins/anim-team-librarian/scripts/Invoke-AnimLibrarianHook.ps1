$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'LibrarianState.ps1')

try {
    $directory = Get-LibrarianStateDirectory
    $configuration = Get-LibrarianConfig $directory
    if ($configuration.mode -eq 'AccountSync') {
        $reader = [IO.StreamReader]::new([Console]::OpenStandardInput(), [Text.UTF8Encoding]::new($false,$true))
        try { $payload = $reader.ReadToEnd() | ConvertFrom-Json } finally { $reader.Dispose() }
        if ($payload.hook_event_name -eq 'Stop') {
            $seat = Get-LibrarianSeatDirectory $directory $configuration.enrollmentId
            $session = [string]$payload.session_id
            $turn = [string]$payload.turn_id
            if ($session -match '^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$' -and
                $turn -cmatch '^[a-zA-Z0-9_.-]{1,160}$') {
                $key = $session.ToLowerInvariant() + '|' + $turn
                Write-LibrarianJson (Join-Path $seat ('turn-' + (Get-LibrarianKey $key) + '.json')) @{
                    enrollmentId=$configuration.enrollmentId; turnKey=$key
                }
            } else {
                # Older hook payloads may omit turn_id. A full inventory can still reconcile the seat.
                Add-LibrarianFullRequest $seat $configuration.enrollmentId
            }
            # A later day's activity reconciles history missed while hooks were unavailable.
            $day = [DateTime]::UtcNow.ToString('yyyy-MM-dd')
            $lastFull = Join-Path $seat 'last-full.json'
            Assert-LibrarianPrivatePath $lastFull
            if (-not [IO.File]::Exists($lastFull) -or (Read-LibrarianJson $lastFull).utcDate -ne $day) {
                Write-LibrarianJson (Join-Path $seat ('full-' + $day + '.json')) @{enrollmentId=$configuration.enrollmentId}
            }
            Start-LibrarianWorker $configuration $seat
        }
    }
} catch {
    [Console]::Error.WriteLine('Librarian scheduling failed. Check the enrollment and run manual sync to recover.')
}
[Console]::WriteLine('{}')


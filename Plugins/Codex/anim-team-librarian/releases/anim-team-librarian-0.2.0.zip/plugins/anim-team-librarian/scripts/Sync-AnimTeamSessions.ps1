#requires -Version 7.2
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'LibrarianState.ps1')
$directory = Get-LibrarianStateDirectory
$config = Get-LibrarianConfig $directory
if ($config.mode -ne 'AccountSync') {
    throw 'Run Configure-AnimLibrarian.ps1 -EnableAccountSync to enroll the signed-in seat first.'
}
& (Join-Path $PSScriptRoot 'Drain-AnimLibrarianQueue.ps1') -EnrollmentId $config.enrollmentId -RequestFull


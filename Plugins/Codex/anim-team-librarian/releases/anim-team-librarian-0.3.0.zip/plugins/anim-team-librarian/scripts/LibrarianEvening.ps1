function Get-LibrarianLocalNow { [DateTimeOffset]::Now }

function Get-LibrarianEveningRecord([string]$Directory,[string]$Name) {
    $path = Join-Path $Directory $Name
    Assert-LibrarianPrivatePath $path
    if ([IO.File]::Exists($path)) { Read-LibrarianJson $path }
}

function Get-LibrarianEveningStatus($Config,[string]$Seat) {
    $now = Get-LibrarianLocalNow
    $format = [Globalization.CultureInfo]::InvariantCulture
    $state = [ordered]@{
        status='NotEnrolled'; email=$Config.email; eveningTime=$Config.eveningTime
        firstEveningDate=$Config.firstEveningDate; checkedAtLocal=$now.ToString('o')
        latestDueDate=$null; pending=$false; overdue=$false; lastCompleted=$null
        currentReceipt=$null; lastAttempt=$null; nextDueLocal=$null
    }
    if (-not $Config) { return $state }
    if ($Config.schemaVersion -ne 3) {
        $state.status = if ($Config.mode -eq 'Disabled') { 'Disabled' } else { 'ScheduleUpgradeRequired' }
        return $state
    }
    $first = [datetime]::ParseExact($Config.firstEveningDate,'yyyy-MM-dd',$format)
    $time = [timespan]::ParseExact($Config.eveningTime,'hh\:mm',$format)
    $today = $now.Date.Add($time)
    $due = if ($now.DateTime -ge $today) { $today } else { $today.AddDays(-1) }
    $next = $due.AddDays(1)
    if ($first -gt $next.Date) { $next = $first.Add($time) }
    if ($due.Date -ge $first) { $state.latestDueDate = $due.ToString('yyyy-MM-dd',$format) }
    $complete = Get-LibrarianEveningRecord $Seat 'evening-completed.json'
    $attempt = Get-LibrarianEveningRecord $Seat 'evening-attempt.json'
    if ($complete) {
        if ($complete.enrollmentId -cne $Config.enrollmentId -or $complete.status -cne 'Completed') { throw 'Invalid evening receipt.' }
        $lastDate = [datetime]::ParseExact($complete.batchDate,'yyyy-MM-dd',$format)
        $state.lastCompleted = $complete
        if ($next.Date -le $lastDate) { $next = $lastDate.AddDays(1).Add($time) }
        if ($complete.batchDate -ceq $state.latestDueDate) { $state.currentReceipt = $complete }
    }
    $state.lastAttempt = if ($attempt -and (!$complete -or $attempt.batchDate -gt $complete.batchDate)) { $attempt } else { $complete }
    if ($Config.mode -ne 'AccountSync') { $state.status = 'Disabled'; return $state }
    $state.nextDueLocal = $next.ToString('yyyy-MM-ddTHH:mm:ss',$format)
    $state.pending = [bool]($state.latestDueDate -and (!$complete -or $state.latestDueDate -gt $complete.batchDate))
    $state.overdue = $state.pending -and $now.DateTime -gt $due
    $state.status = if ($state.pending) {
        if ($attempt -and $attempt.batchDate -ceq $state.latestDueDate) { 'RetryPending' } else { 'Due' }
    } elseif ($state.currentReceipt) { 'Completed' } else { 'Waiting' }
    return $state
}

function Remove-LibrarianEveningStage([string]$Seat,[string]$Path) {
    $absolute = [IO.Path]::GetFullPath($Path)
    if ([IO.Path]::GetDirectoryName($absolute) -ne [IO.Path]::GetFullPath($Seat) -or
        [IO.Path]::GetFileName($absolute) -cnotmatch '^(collect-[a-f0-9]{32}|evening-\d{4}-\d{2}-\d{2})$') {
        throw 'Invalid evening staging location.'
    }
    Assert-LibrarianPrivatePath $absolute -Protected
    if (-not [IO.Directory]::Exists($absolute)) { return }
    # Staging contains only metadata files and one flat, protected document directory.
    foreach ($entry in [IO.Directory]::GetFileSystemEntries($absolute)) {
        Assert-LibrarianPrivatePath $entry
        if ([IO.Directory]::Exists($entry)) {
            if ([IO.Path]::GetFileName($entry) -cne 'documents') { throw 'Unexpected evening staging directory.' }
            Assert-LibrarianPrivatePath $entry -Protected
            foreach ($file in [IO.Directory]::GetFileSystemEntries($entry)) {
                Assert-LibrarianPrivatePath $file
                if ([IO.Directory]::Exists($file)) { throw 'Unexpected evening staging entry.' }
            }
        }
    }
    [IO.Directory]::Delete($absolute,$true)
}

function Assert-LibrarianCounts($Record,[string[]]$Names) {
    foreach ($name in $Names) {
        $count = $Record.$name
        if (($count -isnot [int] -and $count -isnot [long]) -or $count -lt 0) { throw 'Invalid component counts.' }
    }
}

function Get-LibrarianDocumentCount([string]$Directory) {
    Assert-LibrarianPrivatePath $Directory -Protected
    $entries = [IO.Directory]::GetFileSystemEntries($Directory)
    foreach ($entry in $entries) {
        Assert-LibrarianPrivatePath $entry
        if ([IO.Directory]::Exists($entry) -or
            [IO.Path]::GetFileName($entry) -cnotmatch '^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}\.md$') {
            throw 'Invalid evening snapshot document.'
        }
    }
    return $entries.Length
}

function Invoke-LibrarianEvening($Config,[string]$Directory,[string]$Seat,$Status) {
    # Caller holds collection.lock. Only the outbound transaction holds enrollment.lock,
    # allowing disable/replacement while the account's history is being read.
    $date = $Status.latestDueDate
    $stage = $null
    $frozen = Join-Path $Seat ('evening-' + $date)
    $attempt = [ordered]@{enrollmentId=$Config.enrollmentId;batchDate=$date;checkedAtLocal=$Status.checkedAtLocal
        status='RetryPending';reason='AccountVerificationFailed';activeThreads=0;archivedThreads=0;documents=0
        skipped=0;failures=0;changed=0;unchanged=0;older=0;conflicts=0;commit=$null;head=$null;outcome=$null}
    try {
        if (-not (Test-LibrarianBinding $Config (Get-LibrarianIdentity))) { $attempt.reason='AccountChanged'; throw 'Hold' }
        $attempt.reason = 'DestinationVisibilityUnverified'
        if ((Get-LibrarianRepositoryHttpStatus) -ne 404) { throw 'Hold' }
        $attempt.reason = 'CollectionFailed'
        Assert-LibrarianPrivatePath $frozen -Protected
        $recovering = [IO.Directory]::Exists($frozen)
        if (!$recovering) {
            $stage = Join-Path $Seat ('collect-' + [guid]::NewGuid().ToString('N'))
            New-LibrarianPrivateDirectory $stage
            $docs = Join-Path $stage 'documents'
            New-LibrarianPrivateDirectory $docs
            $collection = & (Join-Path $PSScriptRoot 'Collect-AnimTeamHistory.ps1') -OutputDirectory $docs -ExpectedEmail $Config.email -PinnedUserId $Config.userId 2>$null | ConvertFrom-Json
            if (-not (Test-LibrarianBinding $Config $collection)) { $attempt.reason='AccountChanged'; throw 'Hold' }
        } else {
            $docs = Join-Path $frozen 'documents'
            $collection = Get-LibrarianEveningRecord $frozen 'collection.json'
        }
        $counters = @('activeThreads','archivedThreads','documents','skipped','failures')
        Assert-LibrarianCounts $collection $counters
        foreach ($name in $counters) { $attempt[$name] = $collection.$name }
        if ($attempt.failures -or $collection.failedSessions.Count -or $collection.missing.Count -or
            $attempt.documents -ne ($attempt.activeThreads + $attempt.archivedThreads) -or
            $attempt.documents -ne (Get-LibrarianDocumentCount $docs)) { $attempt.reason='CollectionIncomplete'; throw 'Hold' }
        $attempt.reason = 'EnrollmentVerificationFailed'
        $gate = Open-LibrarianLock (Join-Path $Directory 'enrollment.lock')
        try {
            $active = Get-LibrarianConfig $Directory
            if ($active.mode -ne 'AccountSync' -or $active.schemaVersion -ne 3 -or $active.enrollmentId -cne $Config.enrollmentId -or
                $active.eveningTime -cne $Config.eveningTime -or $active.firstEveningDate -cne $Config.firstEveningDate -or
                -not (Test-LibrarianBinding $Config $active)) { $attempt.reason='EnrollmentChanged'; throw 'Hold' }
            $attempt.reason = 'AccountVerificationFailed'
            if (-not (Test-LibrarianBinding $Config (Get-LibrarianIdentity))) { $attempt.reason='AccountChanged'; throw 'Hold' }
            $attempt.reason = 'SnapshotFailed'
            if (!$recovering) {
                $summary = @{}
                foreach ($name in $counters) { $summary[$name] = $attempt[$name] }
                Write-LibrarianJson (Join-Path $stage 'collection.json') $summary
                [IO.Directory]::Move($stage,$frozen)
                $stage = $null
                $docs = Join-Path $frozen 'documents'
            }
            $attempt.reason = 'PublishFailed'
            $published = Get-LibrarianEveningRecord $frozen 'publication.json'
            $recorded = $null -ne $published
            if (!$recorded) {
                $publishArgs = @{DocumentDirectory=$docs; Email=$Config.email; StateDirectory=$Seat
                    RequireCompleteBatch=$true; BatchDate=$date; ReceiptDirectory=$frozen}
                $published = & (Join-Path $PSScriptRoot 'Publish-AnimTeamSessions.ps1') @publishArgs 2>$null | ConvertFrom-Json
            }
            Assert-LibrarianCounts $published @('pushed','unchanged','older','conflicts','deferred')
            if (($published.pushed + $published.unchanged + $published.older + $published.conflicts + $published.deferred) -ne $attempt.documents) { throw 'Invalid publication totals.' }
            if ($published.conflicts -or $published.deferred) {
                $attempt.conflicts = $published.conflicts
                $attempt.reason = 'ConflictingSessionVersions'
                # A fresh, atomic rejection made no remote change. A later collection can
                # resolve it. Keep a retried snapshot if an earlier push result was lost.
                if (!$recovering -and !$published.pushed) { Remove-LibrarianEveningStage $Seat $frozen }
                throw 'Hold'
            }
            $objectId = '^(?:[a-f0-9]{40}|[a-f0-9]{64})$'
            if (($attempt.documents -gt 0 -and $published.head -cnotmatch $objectId) -or
                ($published.pushed -gt 0 -and $published.commit -cnotmatch $objectId) -or
                ($published.pushed -eq 0 -and ($published.commit -or $published.recovered))) { throw 'Invalid publication receipt.' }
            $attempt.reason = 'CheckpointFailed'
            if (!$recorded) {
                $published | Add-Member -NotePropertyName verifiedAfterRetry -NotePropertyValue $recovering
                Write-LibrarianJson (Join-Path $frozen 'publication.json') $published
            }
            $attempt.changed = $published.pushed
            foreach ($name in 'unchanged','older','commit','head') { $attempt[$name] = $published.$name }
            if ($published.recovered) { $attempt.outcome = 'RecoveredCommit' }
            elseif ($attempt.changed) { $attempt.outcome = 'Changed' }
            elseif ($attempt.documents -gt 0 -and ($published.verifiedAfterRetry -or $published.uncertain)) {
                # Identical/superseded content proves the frozen snapshot is covered.
                # The fetched head alone does not prove who originally published it.
                $attempt.changed = $null
                $attempt.outcome = 'VerifiedAfterRetry'
            } else { $attempt.outcome = 'NoChanges' }
            $attempt.checkedAtLocal = (Get-LibrarianLocalNow).ToString('o')
            $complete = [ordered]@{}
            foreach ($name in $attempt.Keys) { $complete[$name] = $attempt[$name] }
            $complete.status = 'Completed'
            $complete.reason = $null
            Write-LibrarianJson (Join-Path $Seat 'evening-completed.json') $complete -Replace
        } finally { $gate.Dispose() }
    } catch {
        # Persist only classified reasons. Collector and Git exceptions can contain private data.
        Write-LibrarianJson (Join-Path $Seat 'evening-attempt.json') $attempt -Replace
        return $false
    } finally {
        if ($stage) { Remove-LibrarianEveningStage $Seat $stage }
    }
    Remove-LibrarianEveningStage $Seat $frozen
    return $true
}

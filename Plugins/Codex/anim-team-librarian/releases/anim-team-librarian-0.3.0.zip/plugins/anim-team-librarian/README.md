# Anim Team Librarian

At **22:00 (10:00 PM) in each workstation’s local time zone**, Anim Team Librarian checks the enrolled animator’s active and archived Codex chats across all projects. It commits changed documents together to `main` in the team repository. Each session has a stable Markdown filename.

```text
YHAnimationStudios/YH_Knowledge_database
└── Animators team/Codex usage data/<seat-email>/<session-id>.md
```

Each enrolled workstation batches its own saved chats. An animator using multiple workstations can enroll each one into the same seat folder. Repository readers can read the conversations. The plugin includes visible user and assistant text and masks common credential formats. Tool results, attachments and private reasoning are excluded.

## Install or upgrade

1. Sign in to Codex with your team seat. Use Git for Windows with write access to the team repository’s `main` branch and PowerShell 7.2 or later.
2. Extract the release to a permanent folder with its `.agents` and `plugins` directories. For an existing local marketplace, replace its release files in its registered folder.
3. In PowerShell 7, open that marketplace folder and run the following commands. On an existing registration you can skip `marketplace add`.

   ```powershell
   codex plugin marketplace add .
   $release = codex plugin add anim-team-librarian@anim-team-tools --json | ConvertFrom-Json
   $scripts = Join-Path $release.installedPath 'scripts'
   & "$scripts\Collect-AnimTeamHistory.ps1" -InventoryOnly
   & "$scripts\Configure-AnimLibrarian.ps1" -EnableAccountSync -EveningTime '22:00'
   ```

Enrollment creates a visible Windows scheduled task under the current Windows user. Run enrollment once on each workstation, including when upgrading 0.2.0. The upgrade preserves the signed-in seat and its previously confirmed document versions. The first scheduled evening is the enrollment date. Enrolling after the deadline checks that evening immediately.

## Evening batches and missed runs

The task runs with Codex open or closed while the enrolled Windows user is signed in. It checks at 22:00, at sign-in, and every 30 minutes. At each check it compares the most recent evening deadline with the last successful batch. After several missed evenings, it reconciles the saved chats together on the next available check. Changes made after a completed evening batch wait for the following evening.

A successful upload records the Git commit. An evening with no changed documents records a successful check locally. An offline workstation, unavailable seat identity, incomplete collection or conflicting session versions leaves work due for retry. The publisher keeps all changed documents in the same batch.

## Check the result

```powershell
& "$scripts\Configure-AnimLibrarian.ps1" -Status
```

The status shows the local deadline, most recent due evening, completion receipt and last attempt. The Windows task’s next wake-up may be a routine 30-minute check. Run `Sync-AnimTeamSessions.ps1` to retry a due batch immediately. It uses the same evening deadline.

| Status | Meaning |
| --- | --- |
| `Waiting` | The first scheduled evening is still ahead. |
| `Due` or `RetryPending` | A deadline has passed. Check `lastAttempt.reason` for a failed attempt. |
| `Completed` | `currentReceipt.batchDate` identifies the completed evening. `Changed` and `RecoveredCommit` include the commit SHA. `NoChanges` means the check succeeded without a new commit. `VerifiedAfterRetry` means Git already covers that batch, but the exact original commit could not be established. |

To stop this workstation’s future uploads and remove its scheduled task, run the following command before uninstalling. Documents already committed stay in GitHub.

```powershell
& "$scripts\Configure-AnimLibrarian.ps1" -DisableAccountSync
```

---
name: anim-team-librarian
description: Use when a user wants to inspect, count, or locally reconcile eligible Codex conversations for an Unreal animation project.
---

# Anim Team Librarian

Use the bundled Windows collector for local Codex Desktop conversations. See [installation and capture modes](../../README.md).

- Establish the user's intended saved project root. A moved project can have distinct historical and current roots. Use a root the user explicitly approved or the appropriate entry in their local Librarian configuration.
- For counts, invoke [the collector](../../scripts/Collect-AnimTeamHistory.ps1) through PowerShell 7.2 or later with `-ProjectRoot`. For an expressly requested local export or backfill, use `-ProjectRoot`, `-Export`, and `-DailySnapshot`. Report the aggregate result and local ZIP path.
- Inspect `%LOCALAPPDATA%\AnimTeamLibrarian\plugin-state\last-*.json` for the most recent hook status when diagnosing an installed plugin. If App Server or the local profile is unavailable, report the blocker.
- Treat local export ZIPs as restricted raw archives. Keep message bodies out of routine status reports. A request to share with others needs a separately approved redacted copy and destination.

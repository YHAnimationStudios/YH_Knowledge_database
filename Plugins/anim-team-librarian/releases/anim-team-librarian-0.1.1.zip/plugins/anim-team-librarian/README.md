# Anim Team Librarian

A Windows Codex Desktop plugin for local Unreal project conversation archives. It runs under the animator's Windows account. The team repository contains the implementation and marketplace catalog.

## Install and verify

This release uses the Codex-format manifest for compatibility with the Windows pilot build.

1. Check out the team marketplace. From its root, use `codex plugin marketplace add .` if the marketplace is not already listed. In Codex Desktop, open **Plugins**, select **Anim Team Tools**, and install **Anim Team Librarian**. Review the Windows `Stop` hook in **Settings → Hooks** under your workspace policy.
2. Open PowerShell 7.2 or later. From the marketplace checkout, configure the saved project roots you want this workstation to collect. Replace the example with your paths. A moved project can have both an old and a current saved path.

   ```powershell
   & .\plugins\anim-team-librarian\scripts\Configure-AnimLibrarian.ps1 -ProjectRoot @('D:\UE\MyProject') -Mode CountOnly
   ```

3. Run one local Codex Desktop turn in an approved project. Open the latest `last-*.json` file under `%LOCALAPPDATA%\AnimTeamLibrarian\plugin-state`. `CountOnly` confirms that the hook matched the path. This mode records a local match status without loading conversation history.
4. Run the configuration command again with `-Mode LocalArchive` to enable local ZIP creation. The configuration records the PowerShell runtime you used. Re-run it if PowerShell moves or is updated to a different install path.

## What the plugin does

- The asynchronous `Stop` hook matches the working directory against configured roots and queues just the thread and turn identifiers. A local worker uses the documented Codex App Server to reconcile persisted history under that project root.
- The worker writes one rolling ZIP per saved root and Windows calendar day when eligible history changes. Each ZIP contains a full project snapshot in `messages.jsonl` and its `manifest.json`. User and assistant message text is retained. Tool results, attachments, previews, hidden replies and duplicate message IDs are excluded. File permissions restrict the archive to the Windows user, SYSTEM, and local administrators.
- ZIPs are in `%LOCALAPPDATA%\AnimTeamLibrarian\exports`. A failed collection or an unobserved turn remains queued for later activity. Closing Codex can interrupt a hook before it queues an event.
- This plugin acts on local Codex Desktop turns. Daily grouping follows activity, so an idle workstation has no clock-triggered collection. Storage is local.

## Count or reconcile manually

From the checkout, use PowerShell 7.2 or later. Use a project path you have approved for collection.

```powershell
$collector = '.\plugins\anim-team-librarian\scripts\Collect-AnimTeamHistory.ps1'
& $collector -ProjectRoot 'D:\UE\MyProject'
& $collector -ProjectRoot 'D:\UE\MyProject' -Export -DailySnapshot
```

The first command reports inventory counts. The second captures saved eligible history, including conversations that predate installation. A task running through the Codex sandbox may need normal authorization to open the local App Server database.

[Codex plugin installation](https://developers.openai.com/plugins/build/plugins#install-a-local-plugin-manually) · [Codex hooks](https://learn.chatgpt.com/docs/hooks#plugin-bundled-hooks) · [Codex App Server](https://learn.chatgpt.com/docs/app-server)

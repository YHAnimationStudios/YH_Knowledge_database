#requires -Version 7.2
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $ProjectRoot,
    [switch] $Export,
    [switch] $DailySnapshot,
    [AllowEmptyCollection()] [string[]] $TrackedTurns = @()
)

$ErrorActionPreference = 'Stop'
$utf8 = [Text.UTF8Encoding]::new($false, $true)
$script:requestId = 0
$script:rpcCode = $null
$script:rpcMethod = $null
$server = $null

function Get-WindowsPath([string] $Path) {
    $normalized = $Path.Replace('/', '\')
    if ($normalized.StartsWith('\\?\UNC\', [StringComparison]::OrdinalIgnoreCase)) {
        $normalized = '\\' + $normalized.Substring(8)
    } elseif ($normalized.StartsWith('\\?\', [StringComparison]::Ordinal)) {
        $normalized = $normalized.Substring(4)
    }
    if ([IO.Path]::IsPathFullyQualified($normalized)) {
        [IO.Path]::TrimEndingDirectorySeparator([IO.Path]::GetFullPath($normalized))
    }
}

function Test-ProjectPath([string] $Path, [string] $Root) {
    $normalized = Get-WindowsPath $Path
    return [bool]($normalized -and (
        $normalized.Equals($Root, [StringComparison]::OrdinalIgnoreCase) -or
        $normalized.StartsWith($Root + '\', [StringComparison]::OrdinalIgnoreCase)
    ))
}

function Send-Rpc($Message) {
    $server.StandardInput.WriteLine((ConvertTo-Json -InputObject $Message -Depth 12 -Compress))
    $server.StandardInput.Flush()
}

function Invoke-Rpc([string] $Method, [hashtable] $Parameters) {
    $script:requestId++
    $script:rpcMethod = $Method
    $script:rpcCode = $null
    Send-Rpc @{ id = $requestId; method = $Method; params = $Parameters }
    $deadline = [DateTime]::UtcNow.AddSeconds(60)
    while ([DateTime]::UtcNow -lt $deadline) {
        $read = $server.StandardOutput.ReadLineAsync()
        $milliseconds = [int][Math]::Max(1, ($deadline - [DateTime]::UtcNow).TotalMilliseconds)
        if (-not $read.Wait($milliseconds)) { throw [TimeoutException]::new() }
        if ($null -eq $read.Result) { throw [IO.EndOfStreamException]::new() }
        $response = ConvertFrom-Json -InputObject $read.Result -AsHashtable -Depth 128
        if ($response.id -ne $requestId -or $response.Contains('method')) { continue }
        if ($response.Contains('error')) {
            $code = $response.error.code
            if ($code -is [long] -or $code -is [int]) { $script:rpcCode = $code }
            throw [InvalidOperationException]::new()
        }
        if (-not $response.Contains('result')) { throw [IO.InvalidDataException]::new() }
        return $response.result
    }
    throw [TimeoutException]::new()
}

function Get-PagedRows([string] $Method, [hashtable] $Filters) {
    $cursors = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    do {
        $page = Invoke-Rpc $Method $Filters
        if ($null -eq $page -or -not $page.Contains('data') -or -not $page.Contains('nextCursor')) {
            throw [IO.InvalidDataException]::new()
        }
        foreach ($row in $page.data) { $row }
        $cursor = $page.nextCursor
        if ($null -ne $cursor) {
            if (-not $cursors.Add($cursor)) { throw [IO.InvalidDataException]::new() }
            $Filters.cursor = $cursor
        }
    } while ($null -ne $cursor)
}

function Get-PlainUserText($Part) {
    if (@($Part.text_elements).Count -eq 0 -or $null -eq $Part.text_elements) {
        return [string]$Part.text
    }
    $bytes = $utf8.GetBytes([string]$Part.text)
    $position = 0
    $text = [Text.StringBuilder]::new()
    foreach ($range in ($Part.text_elements | ForEach-Object { $_.byteRange } | Sort-Object start)) {
        if ($null -eq $range.start -or $null -eq $range.end -or $range.start -lt $position -or
            $range.end -lt $range.start -or $range.end -gt $bytes.Length) {
            throw [IO.InvalidDataException]::new()
        }
        $null = $text.Append($utf8.GetString($bytes, $position, $range.start - $position))
        $position = $range.end
    }
    $null = $text.Append($utf8.GetString($bytes, $position, $bytes.Length - $position))
    return $text.ToString()
}

function Get-MessageRecord([string] $ThreadId, [string] $TurnId, $Item, $Seen) {
    switch ($Item.type) {
        'userMessage' {
            $role = 'user'
            $parts = @($Item.content | Where-Object { $_.type -eq 'text' } | ForEach-Object {
                Get-PlainUserText $_
            } | Where-Object { $_.Length -gt 0 })
        }
        'agentMessage' {
            $display = $Item.moderation.display.mode
            if (($display -and $display -ne 'show') -or ($Item.moderation.moderated -and -not $display)) {
                return
            }
            $role = 'assistant'
            $parts = @($Item.text | Where-Object { $_.Length -gt 0 })
        }
        default { return }
    }
    if ($parts.Count -eq 0) { return }
    if ([string]::IsNullOrEmpty($TurnId) -or [string]::IsNullOrEmpty($Item.id)) {
        throw [IO.InvalidDataException]::new()
    }
    if ($Seen.Add([Tuple[string,string,string]]::new($ThreadId, $TurnId, $Item.id))) {
        [ordered]@{ threadId = $ThreadId; turnId = $TurnId; itemId = $Item.id; role = $role; textParts = $parts }
    }
}

function Get-ThreadMessages($Thread, $Seen) {
    if ($Thread.historyMode -eq 'paginated') {
        Get-PagedRows 'thread/items/list' @{threadId = $Thread.id; sortDirection = 'asc'; limit = 50} |
            ForEach-Object { Get-MessageRecord $Thread.id $_.turnId $_.item $Seen }
    } else {
        Get-PagedRows 'thread/turns/list' @{threadId = $Thread.id; sortDirection = 'asc'; itemsView = 'full'; limit = 10} |
            ForEach-Object {
                $turn = $_
                foreach ($item in $turn.items) { Get-MessageRecord $Thread.id $turn.id $item $Seen }
            }
    }
}

function Get-LocalOutputDirectory {
    $local = [Environment]::GetFolderPath('LocalApplicationData')
    if ([string]::IsNullOrEmpty($local) -or
        [IO.DriveInfo]::new([IO.Path]::GetPathRoot($local)).DriveType -ne 'Fixed') {
        throw [UnauthorizedAccessException]::new()
    }
    $target = [IO.Path]::Combine($local, 'AnimTeamLibrarian', 'exports')
    for ($directory = [IO.DirectoryInfo]::new($target); $directory; $directory = $directory.Parent) {
        if ($directory.Exists -and ($directory.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw [UnauthorizedAccessException]::new()
        }
    }
    return [IO.Directory]::CreateDirectory($target).FullName
}

function New-ArchiveSecurity {
    $security = [Security.AccessControl.FileSecurity]::new()
    $security.SetAccessRuleProtection($true, $false)
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    foreach ($value in @($currentUser, 'S-1-5-18', 'S-1-5-32-544') | Select-Object -Unique) {
        $sid = [Security.Principal.SecurityIdentifier]::new($value)
        $rule = [Security.AccessControl.FileSystemAccessRule]::new($sid, 'FullControl', 'Allow')
        $security.AddAccessRule($rule)
    }
    return $security
}

function Get-DailySnapshotName([string] $Root, [string] $Date) {
    $rootHash = [Security.Cryptography.SHA256]::HashData($utf8.GetBytes($Root.ToUpperInvariant()))
    return "project-$([Convert]::ToHexString($rootHash))-$Date.zip"
}

function Test-SnapshotContents([IO.Compression.ZipArchive] $Zip, $Manifest, [switch] $AllowOlderTimestamp) {
    $manifestEntry = $Zip.GetEntry('manifest.json')
    $messagesEntry = $Zip.GetEntry('messages.jsonl')
    if ($Zip.Entries.Count -ne 2 -or $null -eq $manifestEntry -or $null -eq $messagesEntry) {
        return $false
    }

    $manifestStream = $manifestEntry.Open()
    try {
        $document = [System.Text.Json.JsonDocument]::Parse(
            $manifestStream, [System.Text.Json.JsonDocumentOptions]::new()
        )
        try {
            if ($document.RootElement.ValueKind -ne 'Object') { return $false }
            $keys = [Collections.Generic.HashSet[string]]::new([string[]]$Manifest.Keys, [StringComparer]::Ordinal)
            foreach ($property in $document.RootElement.EnumerateObject()) {
                if (-not $keys.Remove($property.Name)) { return $false }
                if ($property.Name -ceq 'collectedAtUtc' -and $AllowOlderTimestamp) {
                    if ($property.Value.ValueKind -ne 'String') { return $false }
                    $timestamp = [DateTimeOffset]::MinValue
                    if (-not [DateTimeOffset]::TryParseExact(
                        $property.Value.GetString(), 'o', [Globalization.CultureInfo]::InvariantCulture,
                        [Globalization.DateTimeStyles]::None, [ref]$timestamp
                    ) -or $timestamp.Offset -ne [TimeSpan]::Zero) { return $false }
                } elseif ($property.Name -ceq 'projectRoot') {
                    if ($property.Value.ValueKind -ne 'String' -or -not [string]::Equals(
                        $property.Value.GetString(), $Manifest.projectRoot, [StringComparison]::OrdinalIgnoreCase
                    )) { return $false }
                } elseif ($property.Value.GetRawText() -cne (ConvertTo-Json -InputObject $Manifest[$property.Name] -Compress)) {
                    return $false
                }
            }
            if ($keys.Count -ne 0) { return $false }
        } finally { $document.Dispose() }
    } finally { $manifestStream.Dispose() }

    $messageStream = $messagesEntry.Open()
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $actualHash = [Convert]::ToHexString($sha.ComputeHash($messageStream))
        return $actualHash -ceq $Manifest.messagesSha256
    } finally { $messageStream.Dispose(); $sha.Dispose() }
}

function Test-ExistingSnapshot([string] $Path, $Manifest, $Security) {
    try {
        $attributes = [IO.File]::GetAttributes($Path)
    } catch [IO.FileNotFoundException] {
        return $false
    }
    if ($attributes -band ([IO.FileAttributes]::Directory -bor [IO.FileAttributes]::ReparsePoint)) {
        throw [UnauthorizedAccessException]::new()
    }

    $section = [Security.AccessControl.AccessControlSections]::Access
    $existingSecurity = [IO.FileSystemAclExtensions]::GetAccessControl([IO.FileInfo]::new($Path), $section)
    if (-not $existingSecurity.AreAccessRulesProtected) { return $false }
    $sidType = [Security.Principal.SecurityIdentifier]
    $allowedUsers = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    foreach ($rule in $Security.GetAccessRules($true, $true, $sidType)) {
        $null = $allowedUsers.Add($rule.IdentityReference.Value)
    }
    foreach ($rule in $existingSecurity.GetAccessRules($true, $true, $sidType)) {
        if ($rule.IsInherited -or $rule.AccessControlType -ne 'Allow' -or $rule.FileSystemRights -ne 'FullControl' -or
            $rule.InheritanceFlags -ne 'None' -or $rule.PropagationFlags -ne 'None' -or
            -not $allowedUsers.Remove($rule.IdentityReference.Value)) { return $false }
    }
    if ($allowedUsers.Count -ne 0) { return $false }

    try {
        $existing = [IO.Compression.ZipFile]::OpenRead($Path)
        try {
            return Test-SnapshotContents $existing $Manifest -AllowOlderTimestamp
        } finally { $existing.Dispose() }
    } catch [IO.InvalidDataException], [System.Text.Json.JsonException] {
        return $false
    }
}

function Write-LocalSnapshot([string] $Partial, [string] $Final, $Threads, $Manifest, $Tracked, $Observed, [bool] $Daily) {
    $seen = [Collections.Generic.HashSet[Tuple[string,string,string]]]::new()
    $hash = [Security.Cryptography.IncrementalHash]::CreateHash(
        [Security.Cryptography.HashAlgorithmName]::SHA256
    )
    $createdPartial = $false
    try {
        $security = New-ArchiveSecurity
        $file = [IO.FileSystemAclExtensions]::Create(
            [IO.FileInfo]::new($Partial), 'CreateNew', 'FullControl', 'None', 4096, 'None', $security
        )
        $createdPartial = $true
        try {
            $zip = [IO.Compression.ZipArchive]::new($file, 'Create', $true)
            try {
                $messageStream = $zip.CreateEntry('messages.jsonl').Open()
                try {
                    foreach ($thread in $Threads) {
                        Get-ThreadMessages $thread $seen | ForEach-Object {
                            $json = ConvertTo-Json -InputObject $_ -Depth 8 -Compress
                            $line = $utf8.GetBytes($json + "`n")
                            $messageStream.Write($line, 0, $line.Length)
                            $hash.AppendData($line)
                            if ($Tracked.Count -gt 0) {
                                $turnKey = $_.threadId + '|' + $_.turnId
                                if ($Tracked.Contains($turnKey)) { $null = $Observed.Add($turnKey) }
                            }
                        }
                    }
                } finally { $messageStream.Dispose() }

                $Manifest.messages = $seen.Count
                $Manifest.messagesSha256 = [Convert]::ToHexString($hash.GetHashAndReset())
                $manifestStream = $zip.CreateEntry('manifest.json').Open()
                try {
                    $bytes = $utf8.GetBytes((ConvertTo-Json -InputObject $Manifest -Depth 8))
                    $manifestStream.Write($bytes, 0, $bytes.Length)
                } finally { $manifestStream.Dispose() }
            } finally { $zip.Dispose() }
        } finally { $file.Dispose() }

        $verified = [IO.Compression.ZipFile]::OpenRead($Partial)
        try {
            if (-not (Test-SnapshotContents $verified $Manifest)) { throw [IO.InvalidDataException]::new() }
        } finally { $verified.Dispose() }

        if ($Daily -and (Test-ExistingSnapshot $Final $Manifest $security)) { return 'Unchanged' }
        # Same-directory rename publishes the verified file with the staged file's protected ACL.
        [IO.File]::Move($Partial, $Final, $Daily)
        return 'Archived'
    } finally {
        $hash.Dispose()
        if ($createdPartial -and [IO.File]::Exists($Partial)) { [IO.File]::Delete($Partial) }
    }
}

$stage = 'scope'
try {
    $root = Get-WindowsPath $ProjectRoot
    if (-not $root -or $root -eq [IO.Path]::GetPathRoot($root)) {
        throw [ArgumentException]::new()
    }

    $stage = 'app-server-startup'
    $package = Get-AppxPackage -Name OpenAI.Codex | Select-Object -First 1
    if (-not $package) { throw [IO.FileNotFoundException]::new() }
    $binary = [IO.Path]::Combine($package.InstallLocation, 'app', 'resources', 'codex.exe')
    $start = [Diagnostics.ProcessStartInfo]::new($binary)
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardInput = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $start.StandardInputEncoding = $utf8
    $start.StandardOutputEncoding = $utf8
    foreach ($argument in @('app-server', '--listen', 'stdio://', '-c', 'analytics.enabled=false')) {
        $start.ArgumentList.Add($argument)
    }
    $server = [Diagnostics.Process]::Start($start)
    $stderr = $server.StandardError.ReadToEndAsync()
    $null = Invoke-Rpc 'initialize' @{
        clientInfo = @{name='anim_team_librarian'; title='Anim Team Librarian'; version='0.1.0'}
    }
    Send-Rpc @{method='initialized'; params=@{}}

    $stage = 'project-inventory'
    $inventory = [Collections.Generic.Dictionary[string,object]]::new([StringComparer]::Ordinal)
    $unclassified = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    # Scope against saved paths so a moved or deleted directory can still match.
    foreach ($archived in @($false, $true)) {
        Get-PagedRows 'thread/list' @{
            archived=$archived; sourceKinds=@('vscode','appServer','cli','unknown')
            currentAccountOnly=$true; modelProviders=@(); useStateDbOnly=$true
            sortKey='created_at'; limit=50
        } | ForEach-Object {
            if ((Test-ProjectPath $_.cwd $root) -and -not $_.ephemeral -and -not $_.parentThreadId) {
                if ([string]::IsNullOrWhiteSpace($_.originator)) {
                    $null = $unclassified.Add($_.id)
                } elseif ($_.originator -eq 'Codex Desktop') {
                    $inventory[$_.id] = [pscustomobject]@{
                        id=$_.id; archived=$archived; historyMode=$_.historyMode; forkedFromId=$_.forkedFromId
                    }
                }
            }
        }
    }
    # A fork can include copied history, so require its saved ancestry to be in scope too.
    $threads = @($inventory.Values | Sort-Object id | Where-Object {
        $ancestor = $_.forkedFromId
        $ancestry = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
        while ($ancestor) {
            if (-not $ancestry.Add($ancestor) -or -not $inventory.ContainsKey($ancestor)) { return $false }
            $ancestor = $inventory[$ancestor].forkedFromId
        }
        return $true
    })
    $collectionTime = [DateTimeOffset]::Now
    $manifest = [ordered]@{
        schemaVersion = 1
        projectRoot = $root
        collectedAtUtc = $collectionTime.ToUniversalTime().ToString('o', [Globalization.CultureInfo]::InvariantCulture)
        activeThreads = @($threads | Where-Object { -not $_.archived }).Count
        archivedThreads = @($threads | Where-Object archived).Count
        skippedUnclassifiedThreads = $unclassified.Count
        skippedUnverifiedForks = $inventory.Count - $threads.Count
    }
    $observed = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    $status = 'Preview'
    if ($Export) {
        $stage = 'local-export'
        $status = 'Empty'
        if ($threads.Count -gt 0) {
            $directory = Get-LocalOutputDirectory
            if ($DailySnapshot) {
                $localDate = $collectionTime.ToString('yyyy-MM-dd', [Globalization.CultureInfo]::InvariantCulture)
                $manifest['snapshotLocalDate'] = $localDate
                $archiveName = Get-DailySnapshotName $root $localDate
            } else {
                $stamp = $collectionTime.UtcDateTime.ToString(
                    'yyyyMMddTHHmmssZ', [Globalization.CultureInfo]::InvariantCulture
                )
                $archiveName = "$([IO.Path]::GetFileName($root))-$stamp-$([guid]::NewGuid()).zip"
            }
            $archive = [IO.Path]::Combine($directory, $archiveName)
            $partial = [IO.Path]::Combine($directory, "$([guid]::NewGuid()).zip.partial")
            $tracked = [Collections.Generic.HashSet[string]]::new($TrackedTurns, [StringComparer]::Ordinal)
            $status = Write-LocalSnapshot $partial $archive $threads $manifest $tracked $observed $DailySnapshot.IsPresent
            $manifest['archive'] = $archive
        }
    }
    $manifest['status'] = $status
    $manifest['observedTurns'] = @($observed | Sort-Object)
    $manifest | ConvertTo-Json -Depth 5 -Compress
} catch {
    $reason = $_.Exception.GetType().Name
    if ($stage -eq 'app-server-startup' -and $stderr -and $stderr.IsCompletedSuccessfully -and
        $stderr.Result -match 'unable to open database file|SQLITE_CANTOPEN') {
        $reason = 'AppServerCannotOpenLocalDatabase'
    }
    throw [InvalidOperationException]::new(("Collector stopped at {0} ({1}; RPC={2}; code={3})." -f
        $stage, $reason, $rpcMethod, $rpcCode))
} finally {
    if ($server) {
        try { $server.StandardInput.Close() } catch {}
        try { if (-not $server.WaitForExit(2000)) { $server.Kill() } } catch {}
        $server.Dispose()
    }
}

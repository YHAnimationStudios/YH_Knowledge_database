function Get-LibrarianStateDirectory {
    $local = [Environment]::GetFolderPath('LocalApplicationData')
    if (-not $local -or [IO.DriveInfo]::new([IO.Path]::GetPathRoot($local)).DriveType -ne 'Fixed') {
        throw 'Local application data is unavailable.'
    }
    $directory = Join-Path $local 'AnimTeamLibrarian\plugin-state'
    for ($parent = [IO.DirectoryInfo]::new($directory); $parent; $parent = $parent.Parent) {
        if ($parent.Exists -and ($parent.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw 'The Librarian state path is redirected.'
        }
    }
    return $directory
}

function Get-LibrarianWindowsPath([string] $Path) {
    $normalized = $Path.Replace('/', '\')
    if ($normalized.StartsWith('\\?\UNC\', [StringComparison]::OrdinalIgnoreCase)) {
        $normalized = '\\' + $normalized.Substring(8)
    } elseif ($normalized.StartsWith('\\?\', [StringComparison]::Ordinal)) {
        $normalized = $normalized.Substring(4)
    }
    if ($normalized.StartsWith('\\.\', [StringComparison]::Ordinal)) { return }
    if ($normalized -notmatch '^(?:[A-Za-z]:\\|\\\\[^\\]+\\[^\\]+\\)') { return }
    try {
        $path = [IO.Path]::GetFullPath($normalized)
        if ($path.TrimEnd('\') -ne [IO.Path]::GetPathRoot($path).TrimEnd('\')) { $path.TrimEnd('\') }
    } catch { return }
}

function Get-LibrarianKey([string] $Value) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        return [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Value))).Replace('-', '')
    } finally { $sha.Dispose() }
}

function Get-LibrarianProjectKey([string] $Path) {
    return Get-LibrarianKey $Path.ToUpperInvariant()
}

function Get-LibrarianTurn($Payload, [string[]] $ProjectRoots) {
    if ($Payload.hook_event_name -ne 'Stop' -or $Payload.session_id -notmatch '^[a-zA-Z0-9_.-]{1,160}$' -or
        $Payload.turn_id -notmatch '^[a-zA-Z0-9_.-]{1,160}$') { return }
    $cwd = Get-LibrarianWindowsPath $Payload.cwd
    if (-not $cwd) { return }
    $matched = $ProjectRoots | ForEach-Object { Get-LibrarianWindowsPath $_ } |
        Where-Object {
            $cwd.Equals($_, [StringComparison]::OrdinalIgnoreCase) -or
            $cwd.StartsWith($_ + '\', [StringComparison]::OrdinalIgnoreCase)
        } | Sort-Object Length -Descending | Select-Object -First 1
    if ($matched) {
        [ordered]@{
            root=$matched
            projectKey=(Get-LibrarianProjectKey $matched)
            turnKey=([string]$Payload.session_id + '|' + [string]$Payload.turn_id)
        }
    }
}

function Test-LibrarianPrivateAcl([string] $Path, [switch] $RequireProtected) {
    $section = [Security.AccessControl.AccessControlSections]::Access
    if ($PSVersionTable.PSEdition -eq 'Desktop') {
        $acl = if ([IO.Directory]::Exists($Path)) { [IO.Directory]::GetAccessControl($Path, $section) }
        else { [IO.File]::GetAccessControl($Path, $section) }
    } else {
        $item = if ([IO.Directory]::Exists($Path)) { [IO.DirectoryInfo]::new($Path) }
        else { [IO.FileInfo]::new($Path) }
        $acl = [IO.FileSystemAclExtensions]::GetAccessControl($item, $section)
    }
    if ($RequireProtected -and -not $acl.AreAccessRulesProtected) { return $false }
    $user = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $allowed = @($user, 'S-1-5-18', 'S-1-5-32-544')
    foreach ($rule in $acl.GetAccessRules($true, $true, [Security.Principal.SecurityIdentifier])) {
        if ($rule.AccessControlType -eq 'Allow' -and $rule.IdentityReference.Value -notin $allowed) {
            return $false
        }
    }
    return $true
}

function Get-LibrarianConfig([string] $Directory) {
    $path = Join-Path $Directory 'projects.json'
    if ((Test-Path -LiteralPath $path -PathType Leaf) -and
        (Test-LibrarianPrivateAcl $Directory -RequireProtected) -and
        (Test-LibrarianPrivateAcl $path) -and
        -not ((Get-Item -LiteralPath $path).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        $configuration = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($configuration.schemaVersion -eq 1 -and $configuration.mode -in @('CountOnly','LocalArchive')) {
            return $configuration
        }
    }
}

function Write-LibrarianJson([string] $Path, $Value, [switch] $Replace) {
    $stage = $Path + ".$([guid]::NewGuid()).partial"
    $stream = [IO.File]::Open($stage, 'CreateNew')
    try {
        try {
            $bytes = [Text.UTF8Encoding]::new($false).GetBytes((ConvertTo-Json -InputObject $Value -Depth 6 -Compress))
            $stream.Write($bytes, 0, $bytes.Length)
        } finally { $stream.Dispose() }

        if (-not [IO.File]::Exists($Path)) {
            try {
                [IO.File]::Move($stage, $Path)
                return
            } catch {
                if (-not [IO.File]::Exists($Path)) { throw }
            }
        }
        if ($Replace) { [IO.File]::Replace($stage, $Path, [NullString]::Value) }
    } finally {
        if ([IO.File]::Exists($stage)) { [IO.File]::Delete($stage) }
    }
}

function Get-LibrarianQueueDirectory([string] $StateDirectory, [string] $ProjectKey) {
    if ($ProjectKey -notmatch '^[A-F0-9]{64}$') { throw 'Invalid project key.' }
    $queue = Join-Path $StateDirectory ('queue-' + $ProjectKey)
    $existing = [IO.DirectoryInfo]::new($queue)
    if ($existing.Exists -and ($existing.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        throw 'The Librarian queue is redirected.'
    }
    if ($existing.Exists -and -not (Test-LibrarianPrivateAcl $queue)) { throw 'The Librarian queue permissions are too broad.' }
    return $queue
}

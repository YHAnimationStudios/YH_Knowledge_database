#requires -Version 7.2
[CmdletBinding()]
param([Parameter(Mandatory)] [ValidatePattern('^[A-F0-9]{64}$')] [string] $ProjectKey)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'LibrarianState.ps1')
$directory = Get-LibrarianStateDirectory
$queue = Get-LibrarianQueueDirectory $directory $ProjectKey
if (-not [IO.Directory]::Exists($queue)) { return }

try {
    $lock = [IO.File]::Open((Join-Path $queue 'collector.lock'), 'OpenOrCreate', 'ReadWrite', 'None')
} catch {
    if ($_.Exception.GetBaseException() -is [IO.IOException]) { return }
    throw
}

$statusPath = Join-Path $directory ('last-' + $ProjectKey + '.json')
try {
    for ($attempt = 0; $attempt -lt 3; $attempt++) {
        $configuration = Get-LibrarianConfig $directory
        if ($configuration.mode -ne 'LocalArchive') { return }
        $root = $configuration.projectRoots | ForEach-Object { Get-LibrarianWindowsPath $_ } |
            Where-Object { (Get-LibrarianProjectKey $_) -eq $ProjectKey } | Select-Object -First 1
        if (-not $root) { return }

        $events = @(foreach ($file in (Get-ChildItem -LiteralPath $queue -Filter 'turn-*.json' -File | Sort-Object LastWriteTimeUtc | Select-Object -First 200)) {
            if ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
            try { $key = (Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json).turnKey }
            catch { continue }
            if ($key -match '^[a-zA-Z0-9_.-]{1,160}\|[a-zA-Z0-9_.-]{1,160}$' -and
                $file.Name -eq ('turn-' + (Get-LibrarianKey $key) + '.json')) {
                [ordered]@{path=$file.FullName; turnKey=$key}
            }
        })
        if ($events.Count -eq 0) { return }

        Start-Sleep -Seconds 2
        $collector = Join-Path $PSScriptRoot 'Collect-AnimTeamHistory.ps1'
        $result = & $collector -ProjectRoot $root -Export -DailySnapshot -TrackedTurns ($events | ForEach-Object turnKey) |
            ConvertFrom-Json -AsHashtable
        if ($result.status -notin @('Archived', 'Unchanged', 'Empty')) { throw 'Unexpected collector result.' }
        $observed = [Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
        if ($result.status -ne 'Empty') {
            foreach ($key in $result.observedTurns) { $null = $observed.Add($key) }
        }
        foreach ($event in $events) {
            if ($observed.Contains($event.turnKey)) { [IO.File]::Delete($event.path) }
        }

        $pending = @(Get-ChildItem -LiteralPath $queue -Filter 'turn-*.json' -File).Count
        Write-LibrarianJson $statusPath @{
            status=$result.status; projectRoot=$root; checkedAtUtc=[DateTimeOffset]::UtcNow.ToString('o')
            activeThreads=$result.activeThreads; archivedThreads=$result.archivedThreads
            messages=$result.messages; archive=$result.archive; pendingTurns=$pending
        } -Replace
        if ($pending -eq 0) { break }
    }
} catch {
    Write-LibrarianJson $statusPath @{
        status='RetryPending'; checkedAtUtc=[DateTimeOffset]::UtcNow.ToString('o')
        reason=$_.Exception.GetType().Name
    } -Replace
    exit 1
} finally { $lock.Dispose() }

#requires -Version 7.2
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string[]] $ProjectRoot,
    [ValidateSet('CountOnly','LocalArchive')] [string] $Mode = 'CountOnly'
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'LibrarianState.ps1')

$roots = @(foreach ($supplied in $ProjectRoot) {
    $normalized = Get-LibrarianWindowsPath $supplied
    if (-not $normalized) { throw 'Provide absolute Windows project folders beneath a drive or share root.' }
    $normalized
})
$roots = @($roots | Select-Object -Unique)
$runtime = [Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
if ([IO.Path]::GetFileName($runtime) -ne 'pwsh.exe') { throw 'Open PowerShell 7 and run configuration again.' }

$directory = Get-LibrarianStateDirectory
if (-not [IO.Directory]::Exists($directory)) {
    $acl = [Security.AccessControl.DirectorySecurity]::new()
    $acl.SetAccessRuleProtection($true, $false)
    $user = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    foreach ($value in @($user, 'S-1-5-18', 'S-1-5-32-544') | Select-Object -Unique) {
        $sid = [Security.Principal.SecurityIdentifier]::new($value)
        $rule = [Security.AccessControl.FileSystemAccessRule]::new($sid, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
        $acl.AddAccessRule($rule)
    }
    $null = [IO.FileSystemAclExtensions]::CreateDirectory($acl, $directory)
}
if (-not (Test-LibrarianPrivateAcl $directory -RequireProtected)) { throw 'The Librarian state folder permissions are too broad.' }

$config = [ordered]@{schemaVersion=1; mode=$Mode; projectRoots=$roots; powerShellPath=$runtime}
$path = Join-Path $directory 'projects.json'
Write-LibrarianJson $path $config -Replace
[ordered]@{mode=$Mode; configuredProjects=$roots.Count; configuration=$path} | ConvertTo-Json -Compress

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'LibrarianState.ps1')

try {
    $directory = Get-LibrarianStateDirectory
    $configuration = Get-LibrarianConfig $directory
    if ($configuration) {
        $inputStream = [IO.StreamReader]::new([Console]::OpenStandardInput(), [Text.UTF8Encoding]::new($false, $true))
        try {
            $payload = $inputStream.ReadToEnd() | ConvertFrom-Json
            $turn = Get-LibrarianTurn $payload $configuration.projectRoots
        } finally { $inputStream.Dispose() }
        $payload = $null
        if ($turn) {
            if ($configuration.mode -eq 'CountOnly') {
                Write-LibrarianJson (Join-Path $directory ('last-' + $turn.projectKey + '.json')) @{
                    status='CountOnly'; projectRoot=$turn.root; checkedAtUtc=[DateTimeOffset]::UtcNow.ToString('o')
                } -Replace
            } else {
                $queue = Get-LibrarianQueueDirectory $directory $turn.projectKey
                $null = [IO.Directory]::CreateDirectory($queue)
                $name = 'turn-' + (Get-LibrarianKey $turn.turnKey) + '.json'
                Write-LibrarianJson (Join-Path $queue $name) @{turnKey=$turn.turnKey}
                $runtime = [string]$configuration.powerShellPath
                if ([IO.Path]::GetFileName($runtime) -ne 'pwsh.exe' -or -not [IO.File]::Exists($runtime)) {
                    throw 'PowerShell 7 must be configured again.'
                }
                $worker = Join-Path $PSScriptRoot 'Drain-AnimLibrarianQueue.ps1'
                & $runtime -NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -File $worker -ProjectKey $turn.projectKey *> $null
            }
        }
    }
} catch {
    # Collection failures do not alter the turn. The queue retains items for a later run.
    [Console]::Error.WriteLine('The local Librarian hook could not finish. Check its local configuration and status.')
}
[Console]::WriteLine('{}')
exit 0
